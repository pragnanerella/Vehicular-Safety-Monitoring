#include<REGx52.h>
#include "smcl_lcd8.h"
#include "adc0808.h"
#include "AT_serial.h"

unsigned char a[20],m,i,val1,val2,val3,val4;
bit aa=0;




void message_send();
void enter();
void received();






void MSDelay(unsigned int);
void select_channel(unsigned char);
unsigned int adc(unsigned char);




void MSDelay(unsigned int delay) // Function to generate time delay
{
	
unsigned int i,j;
for(i=0;i<delay;i++)
for(j=0;j<1275;j++);
}


void send_data(unsigned int jk)
{
      //Serial_Out(jk%10000/1000+0x30);
	Serial_Out(jk%1000/100+0x30);
	Serial_Out(jk%100/10+0x30);
	Serial_Out(jk%10/1+0x30);
}


void serial() interrupt 4 
{
	if(RI==1)
	{   
		
            RI=0;
    	    a[m] = SBUF;
		
		    if(a[0] == '4'){m++;}
			
			
			
	 } 
}


void main()
{
	


	IE=0x82;
	InitADC();	
	Lcd8_Init();
	Lcd8_Display(0x80,"ACCIDENT ALERT  ",16);
	Lcd8_Display(0xC0," MONITORING     ",16);
			 Delay(5000);
	
	 Serial_Init(9600); 	Receive(0);
	 Delay(65000);
	Delay(65000);
	Lcd8_Command(0x01);
    

	while(1)
	{
	    val1 = ReadADC(AN0);
		  val2 = ReadADC(AN1);
		  val3 = ReadADC(AN2);
		  val4 = ReadADC(AN3);
		  
		    Lcd8_Display(0x80,"Acc:",4);
	   	 Lcd8_Decimal3(0x84,val1);
		
		
		
		 
		
		  
		
		  if(val2 <= 100)
			{
				 Lcd8_Display(0x89,"IR:NOT",6);
			}
			else
			{
				Lcd8_Display(0x89,"IR:DET",6);
			}
	   	 
		
		  if(val3 <= 100)
			{
				 Lcd8_Display(0xC0,"ALCO:NOT",8);
			}
			else
			{
				Lcd8_Display(0xC0,"ALCO:DET",8);
			}
		  
		 if(val4 <= 100)
			{
				 Lcd8_Display(0xC9,"LDR:NOT",7);
			}
			else
			{
				Lcd8_Display(0xC9,"LDR:DET",7);
			}
			
			 if(val1 >= 100 || val2 > 100 || val3 > 100 || val4 > 100){aa=1;}
			 else{aa = 0;}
		  
		  if(aa){message_send();}

   }
}

void message_send()
{
	
	Serial_Out('*');
	send_data(val1);
	Serial_Out(' ');
	if(val1 > 100){Serial_Conout("FALL DETECTION",14);}

 
	 if(val2 <= 100)
			{
				 Serial_Conout(" IR:NOT",7);
			}
			else
			{
				Serial_Conout(" IR:DET",7);
			}
	   	 
		
		  if(val3 <= 100)
			{
				 Serial_Conout(" ALCO:NOT",9);
			}
			else
			{
				Serial_Conout(" ALCO:DET",9);
			}
		  
		 if(val4 <= 100)
			{
				 Serial_Conout(" LDR:NOT",8);
			}
			else
			{
				Serial_Conout(" LDR:DET",8);
			}
			Serial_Out(0x0d);Serial_Out(0x0a);
			Delay(65000);
	
	
}


