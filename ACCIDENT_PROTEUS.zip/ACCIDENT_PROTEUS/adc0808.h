#ifndef __ADC0808_H
#define __ADC0808_H

void InitADC(void);
unsigned char ReadADC(unsigned char);

// Define ADC Channels
#define AN0		0
#define AN1		1
#define AN2		2
#define AN3		3
#define AN4		4
#define AN5		5
#define AN6		6
#define AN7		7

// Define Pins
sbit Add_A = P2^0;     // Address Pin A
sbit Add_B = P2^1;     // Address Pin B
sbit Add_C = P2^2;     // Address Pin C
sbit ALE   = P2^3;     // Address Latch Enable
sbit EOC   = P2^4;     // End Of Conversion
sbit OE    = P2^5;     // Output Enable
sbit START = P2^6;     // Start Conversion
sbit CLK   = P2^7;     // Clock for AD0808

// Define Data Bus
#define Data_Bus 	P0

#define HalfCycleDelay		10		// usecs

// Function Declarations
void InitADC(void);
unsigned char ReadADC(unsigned char);

#endif



void InitADC(void)
{
	Add_A = 0;		  // Make output
	Add_B = 0;		  // Make output 
	Add_C = 0;		  // Make output
	ALE   = 0;		  // Make output
	EOC   = 1;		  // Make input
	OE    = 0;		  // Make output
	START = 0;		  // Make output
	CLK   = 0;		  // Make output
	
	Data_Bus = 0xFF;  // Make Inputs	
}



unsigned char ReadADC(unsigned char Channel)
{
	unsigned int i = 0;
	unsigned int ADC_value = 0;

	// Select Channel
	switch(Channel)
	{
	case AN0: Add_C = 0;  Add_B = 0;  Add_A = 0; break;
	case AN1: Add_C = 0;  Add_B = 0;  Add_A = 1; break;
	case AN2: Add_C = 0;  Add_B = 1;  Add_A = 0; break;
	case AN3: Add_C = 0;  Add_B = 1;  Add_A = 1; break;
	case AN4: Add_C = 1;  Add_B = 0;  Add_A = 0; break;
	case AN5: Add_C = 1;  Add_B = 0;  Add_A = 1; break;
	case AN6: Add_C = 1;  Add_B = 1;  Add_A = 0; break;
	case AN7: Add_C = 1;  Add_B = 1;  Add_A = 1; break;
	}	   

	__delay_us(HalfCycleDelay);		// 250kHz Frequency
	ALE = 1;						// Enable Address Latch
	CLK = 1; 						// Make CLK High
	__delay_us(HalfCycleDelay);		// 250kHz Frequency
	CLK = 0; 						// Make CLK Low
	START = 1;						// Start ADC Conversion
	__delay_us(HalfCycleDelay);		// 250kHz Frequency
	CLK = 1; 						// Make CLK High
	ALE = 0;						// Disable Address Latch
	__delay_us(HalfCycleDelay);		// 250kHz Frequency
	CLK = 0; 						// Make CLK Low
	START = 0;						// Complete the start pulse

	for(i=0;i<2000;i++)
	{
		CLK = !CLK;					// Toggle Clock
		__delay_us(HalfCycleDelay);	// 250kHz Frequency

		if(!EOC)		  			// Wait for EOC to be low
			break;
	}

	for(i=0;i<2000;i++)
	{
		CLK = !CLK;					// Toggle Clock
		__delay_us(HalfCycleDelay);	// 250kHz Frequency

 		if(EOC)					   	// Wait for EOC to be High	
			break;
	}

	CLK = 0; 						// Make CLK Low
	OE = 1;							// Enable Output
	__delay_us(HalfCycleDelay);		// 250kHz Frequency
	CLK = 1; 						// Make CLK High
	__delay_us(HalfCycleDelay);		// 250kHz Frequency
	CLK = 0; 						// Make CLK Low
	__delay_us(HalfCycleDelay);		// 250kHz Frequency
	CLK = 1; 						// Make CLK High

	ADC_value = Data_Bus;			// Read value

	__delay_us(HalfCycleDelay);		// 250kHz Frequency
	OE = 0;							// Disable Output
	CLK = 0; 						// Make CLK Low
	__delay_us(HalfCycleDelay);		// 250kHz Frequency

	return ADC_value;		 		// Return ADC value
}